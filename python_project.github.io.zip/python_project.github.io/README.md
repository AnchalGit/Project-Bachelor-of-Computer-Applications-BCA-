# project title                      Online Attendance Management System


# About the Project

```
* This project is designed for reducing the pen paper concept to mark-down the attendance.
* More relaibilitiy since this project includs realtime-database(sqlite3).
* In this project we can store around 10,000 student's data and same for faculty.
* There is mainly two section "The faculty" and "The student".
  
```
# requirment 

django 2.2^
python 3.7^


# Run Command 

python manage.py runserver
(Starting development server at http://127.0.0.1:8000/)



# Dummy Student data for sign in
Roll no: 01
Name : yashsrivastava
password : 251125

Roll no: 02
Name : yash bajpai
password : 12345

Roll no: 03
Name : vijay awasthi
password : 12345

Roll no: 04
Name : vibhu
password : 12345


# Dummy faculty data for sign in  
```
username: yashsrivastava
password : 251125

```
